if( document.getElementById("a") ){
     	document.getElementById("a").innerHTML = " a ";
}